#include <stdio.h>

int main (void)
{
	int x;
	x=5;
	
	printf("%d", x);
	return 0;
}
