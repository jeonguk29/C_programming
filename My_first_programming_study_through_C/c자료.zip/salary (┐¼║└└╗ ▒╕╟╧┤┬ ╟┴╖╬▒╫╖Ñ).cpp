#include <stdio.h>
#define MONTHS 12 
int main (void)
{
	double MONTHsalary = 1000.5;
	printf("$ %.2f", MONTHsalary* MONTHS);
	return 0;
}
 
